// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("dead code scan"); }
int main(){
  announce();
  return lionss_run_workload("dead-code-scan");
}

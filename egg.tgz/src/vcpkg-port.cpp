// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("vcpkg port"); }
int main(){
  announce();
  return lionss_run_workload("vcpkg-port");
}

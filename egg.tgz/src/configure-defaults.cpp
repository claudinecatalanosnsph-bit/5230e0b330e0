// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("configure defaults"); }
int main(){
  announce();
  return lionss_run_workload("configure-defaults");
}

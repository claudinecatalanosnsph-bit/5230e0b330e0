// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("uclibc build\n", stdout);
  return lionss_run_workload("uclibc-build");
}

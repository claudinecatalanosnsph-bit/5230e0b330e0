# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(undefined-sanitizer src/undefined-sanitizer.cpp)
set_property(TARGET undefined-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(undefined-sanitizer lionss pthread)

add_executable(package-nsis src/package-nsis.cpp)
set_property(TARGET package-nsis PROPERTY CXX_STANDARD 11)
target_link_libraries(package-nsis lionss pthread)

add_executable(dead-code-scan src/dead-code-scan.cpp)
set_property(TARGET dead-code-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dead-code-scan lionss pthread)

add_executable(simd-throughput src/simd-throughput.cpp)
set_property(TARGET simd-throughput PROPERTY CXX_STANDARD 11)
target_link_libraries(simd-throughput lionss pthread)

add_executable(p99-latency src/p99-latency.cpp)
set_property(TARGET p99-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(p99-latency lionss pthread)

add_executable(vcpkg-port src/vcpkg-port.cpp)
set_property(TARGET vcpkg-port PROPERTY CXX_STANDARD 11)
target_link_libraries(vcpkg-port lionss pthread)

add_executable(dogfood src/dogfood.cpp)
set_property(TARGET dogfood PROPERTY CXX_STANDARD 11)
target_link_libraries(dogfood lionss pthread)

add_executable(startup-latency src/startup-latency.cpp)
set_property(TARGET startup-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(startup-latency lionss pthread)

add_executable(illumos-build src/illumos-build.cpp)
set_property(TARGET illumos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(illumos-build lionss pthread)

add_executable(uclibc-build src/uclibc-build.cpp)
set_property(TARGET uclibc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(uclibc-build lionss pthread)

add_executable(cross-toolchain src/cross-toolchain.cpp)
set_property(TARGET cross-toolchain PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-toolchain lionss pthread)

add_executable(sast-scan src/sast-scan.cpp)
set_property(TARGET sast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(sast-scan lionss pthread)

add_executable(makefiles-build src/makefiles-build.cpp)
set_property(TARGET makefiles-build PROPERTY CXX_STANDARD 11)
target_link_libraries(makefiles-build lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(branch-coverage src/branch-coverage.cpp)
set_property(TARGET branch-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(branch-coverage lionss pthread)

add_executable(protocol-fuzz src/protocol-fuzz.cpp)
set_property(TARGET protocol-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(protocol-fuzz lionss pthread)

add_executable(tag-validation src/tag-validation.cpp)
set_property(TARGET tag-validation PROPERTY CXX_STANDARD 11)
target_link_libraries(tag-validation lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(config-matrix src/config-matrix.cpp)
set_property(TARGET config-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(config-matrix lionss pthread)

add_executable(cold-start-bench src/cold-start-bench.cpp)
set_property(TARGET cold-start-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(cold-start-bench lionss pthread)

add_executable(nix-build src/nix-build.cpp)
set_property(TARGET nix-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nix-build lionss pthread)

add_executable(line-coverage src/line-coverage.cpp)
set_property(TARGET line-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(line-coverage lionss pthread)

add_executable(afl-fuzz src/afl-fuzz.cpp)
set_property(TARGET afl-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(afl-fuzz lionss pthread)

add_executable(conformance-suite src/conformance-suite.cpp)
set_property(TARGET conformance-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(conformance-suite lionss pthread)

add_executable(broken-links src/broken-links.cpp)
set_property(TARGET broken-links PROPERTY CXX_STANDARD 11)
target_link_libraries(broken-links lionss pthread)

add_executable(quarantine-flaky src/quarantine-flaky.cpp)
set_property(TARGET quarantine-flaky PROPERTY CXX_STANDARD 11)
target_link_libraries(quarantine-flaky lionss pthread)

add_executable(openbsd-build src/openbsd-build.cpp)
set_property(TARGET openbsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(openbsd-build lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

